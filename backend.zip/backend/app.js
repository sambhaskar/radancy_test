const express = require('express');
const app = express();
const errorMiddleware = require('./middlewares/error');
const cookieParser = require('cookie-parser')
const path = require('path')
const dotenv = require('dotenv');
dotenv.config({path:path.join(__dirname,"config/config.env")});


app.use(express.json());
app.use(cookieParser());
app.use('/uploads', express.static(path.join(__dirname,'uploads') ) )
const products = require('./routes/product')
const auth = require('./routes/auth')
const roomBook = require('./models/User')
const contactUs = require('./models/ContactUs')

app.use('/api/v1/',products);
app.use('/api/v1/',auth);

app.post('/book-room',(req,res)=>{
    roomBook.create(req.body).then((user)=>res.json(user)).catch((error)=>res.json(error))
})

app.post('/contact-us',(req,res)=>{
    contactUs.create(req.body).then((user)=>res.json(user)).catch((error)=>res.json(error))
})
app.use(errorMiddleware)

module.exports = app;