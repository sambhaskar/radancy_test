const dotenv = require('dotenv');
const products = require('../data/products.json');
const Product = require('../models/productModel');
const connectDatabase = require('../config/database');

const result = dotenv.config({ path: './config/config.env' });
if (result.error) {
  throw result.error;
}

console.log('DB_LOCAL_URI:', process.env.DB_LOCAL_URI); // Check if URI is loaded

const seedProducts = async () => {
  try {
    await connectDatabase();
    console.log('MongoDB connected');

    await Product.deleteMany();
    console.log('Rooms deleted!');

    await Product.insertMany(products);
    console.log('All Rooms added!');

    process.exit(0);
  } catch (error) {
    console.error('Error seeding database:', error.message);
    process.exit(1);
  }
};

seedProducts();
