const mongoose = require('mongoose');

const ContactSchema = new mongoose.Schema({
    name:String,
    email:String,
    phone:String,
    message:String,
})

const ContactModal = mongoose.model("form_registers", ContactSchema)
module.exports = ContactModal;