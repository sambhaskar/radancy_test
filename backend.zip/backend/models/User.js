const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
    name:String,
    address:String,
    checkin:Date,
    checkout:Date,
    email:String,
    phone:String,
    norooms:String,
    noadult:String,
    nochildren:String,  
    roombook:String, 
    roomname:String
})

const UserModal = mongoose.model("room_book", UserSchema)
module.exports = UserModal;