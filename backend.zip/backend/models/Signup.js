const mongoose = require('mongoose'); 


const singUpSchema = new mongoose.Schema({
    name:String,
    email:String,
    password:String
})

const signUp = mongoose.model('signup', singUpSchema);

module.exports = signUp