const bycrpt = require('bcryptjs')
const jsonToken = require('jsonwebtoken')
const signUp = require('../Models/Signup');

// register
const register = async (req,res)=>{
           const {name, password, email}=  req.body;

           try{
                const hasPassword = await bycrpt.hash(password, 12);
                const newSignUp = new signUp({
                        name,email,password:hasPassword
                })
                await newSignUp.save();
                res.status(200).json({
                    success:true,
                    message:"Registration Successfully"
                })
           }
           catch(e){
                console.log(e);
                    res.status(500).json({
                        success:false,
                        message:"Some Error Occured"
                    });
           }
}


// login

const login = async (req,res)=>{
    const {userName, password, email}=  req.body;

    try{

    }
    catch(e){
         console.log(e);
             res.status(500).json({
                 success:false,
                 message:"Some Error Occured"
             });
    }
}


// Logout

const logout = async (req,res)=>{
    const {userName, password, email}=  req.body;

    try{

    }
    catch(e){
         console.log(e);
             res.status(500).json({
                 success:false,
                 message:"Some Error Occured"
             });
    }
}

 module.exports = {register}